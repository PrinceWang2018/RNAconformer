import argparse,json
from dataclasses import asdict
from .core import parse,aform_stem

def main():
    ap=argparse.ArgumentParser(description='RNAFold3D M1 secondary structure and stem geometry kernel')
    ap.add_argument('--sequence',required=True);ap.add_argument('--structure',required=True)
    ap.add_argument('--output',default='m1_output.json')
    a=ap.parse_args();m=parse(a.sequence,a.structure)
    obj=asdict(m);obj['stem_geometry']=[]
    for s in m.stems:
        ids,xyz=aform_stem(s)
        obj['stem_geometry'].append({'residue_indices_0based':ids.tolist(),'guide_xyz_angstrom':xyz.tolist()})
    with open(a.output,'w') as f: json.dump(obj,f,indent=2)
    print(f'{len(m.sequence)} nt; {len(m.pairs)} pairs; {len(m.stems)} stems; output={a.output}')
if __name__=='__main__':main()
