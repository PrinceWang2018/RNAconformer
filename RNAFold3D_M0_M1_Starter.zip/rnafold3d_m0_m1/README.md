# RNAFold3D-Physics — M0/M1 Starter

A minimal, tested, independent RNA secondary-structure parsing and geometry kernel. Intended for RNA up to 200 nt; no machine learning, structure fragments or upstream source code.

## Install and run

```bash
pip install -e .
python -m rnafold3d --sequence GGGAAACCC --structure '(((...)))' --output example.json
python -m unittest discover -s tests -v
```

## Implemented
- Sequence and multi-bracket dot-bracket validation (including crossing base pairs)
- Pair map and consecutive base-pair stem detection
- Unpaired runs and preliminary structural-element adjacency
- Simplified A-form-like helical guide coordinates
- Proper rigid transformations and a conservative endpoint distance feasibility bound
- JSON export and six passing unit tests

## Not implemented
- Complete junction topology graph, precise loop classification, actual atomic A-form RNA geometry, loop closure, physical energies, Monte Carlo, full-atom reconstruction, or validated PDB outputs.

**Important:** Helix points are abstract guide coordinates, not physical atom positions. The endpoint reachability check is only a necessary upper-bound filter, not a sufficient chain-closure test. `T` is normalized to `U`; modified nucleotides are not supported. Bracket types support pseudoknot pair maps but not full pseudoknot topology modeling.

See `M0_AUDIT.md` for source-audit status and follow-up work.
