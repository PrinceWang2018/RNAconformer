# RNAFold3D-Bench v0.2 — M4.2 Curation & Secondary Structure Annotation

This package extends the M4.1 experimental mmCIF collection scripts with a **conservative annotation and audit layer**. No experimental structures are bundled, and no structure-derived secondary structure labels are fabricated.

## Data policy

- **Oracle-2D**: a structure-derived secondary-structure annotation (for example DSSR) supplied by the researcher. This measures *3D assembly conditional on an oracle 2D input*, not independent prediction accuracy.
- **Independent-2D**: a supplied annotation obtained independently of the target 3D structure (experimental 2D probing or sequence-only prediction). Its source and method are recorded.
- Annotation is supplied as dot-bracket (`.dbn`) or reciprocal three-column `.bpseq`.
- Pseudoknots can be represented with `() [] {} <>` when converting BPSEQ; >4 crossing levels fail explicitly.
- Review gates: 30–200 nt, >=95% observed C4' coverage, contiguous polymer label sequence indices, canonical pair review, and manual review flag. Passing these **does not** establish crystal quality, biological assembly correctness, or independent-2D provenance.
- Samples lacking a verified annotation remain **missing_annotation**. The pipeline does not silently infer one from 3D coordinates.
- Original mmCIF and atom identifiers must be retained. Label sequence IDs are not automatically equivalent to author residue numbering.

## Workflow

```bash
pip install biopython
python benchmark_dataset.py --manifest candidate_manifest.json --out dataset
# Or --offline if raw mmCIF files already exist in dataset/raw/

python curate_annotations.py annotate \
  --sample dataset/samples/EXAMPLE_A \
  --annotation external_annotations/EXAMPLE_A.dbn \
  --mode independent_2d \
  --source 'lab-supplied probing data' \
  --method 'SHAPE-constrained secondary structure' \
  --reviewed

python curate_annotations.py inventory --dataset dataset
python -m unittest discover -s tests -v
```

**Do not use `--reviewed` until a researcher has actually reviewed sequence, chain selection, provenance, missing residues, modified bases, and structural conditions.**

## Output

`dataset/samples/<sample_id>/annotations/<mode>/secondary_structure.dbn` and `annotation_qc.json`; `dataset/curation_inventory.csv`. Each annotation carries a SHA-256 of the input and explicit provenance.

## Outstanding scientific checks before a published benchmark

1. Obtain and audit experimental structures; resolve RNA chains, chain breaks, modified nucleotides, multiple models, ligand/protein partners and missing coordinates.
2. Verify chain identity and original `auth_asym_id` / `auth_seq_id` mapping against mmCIF, and compare polymer sequence to observed residues. The M4.1 extractor currently considers canonical observed residues only and is insufficient as the sole final authority for modified RNA.
3. Obtain and verify oracle annotations using an established RNA base-pair annotation tool; document software version and pair classes.
4. Obtain independent annotations separately and document that the target 3D coordinates were not used.
5. Apply sequence-identity / structural-family de-duplication and train/test provenance exclusion if comparing to template/statistical methods.
6. Add RNA-specific eRMSD/INF metrics and independent stereochemical quality checks.

## Current status

The deliverable is a **working curation and annotation pipeline**, not a populated, validated experimental benchmark dataset. Candidate PDB identifiers remain unreviewed until downloaded and checked.
