import json
import tempfile
import unittest
from pathlib import Path
from curate_annotations import parse_dotbracket, parse_bpseq, bpseq_to_dotbracket, annotate_sample, inventory

class TestCuration(unittest.TestCase):
    def test_nested(self):
        x=parse_dotbracket('GGGAAACCC','(((...)))')
        self.assertEqual(x['pair_count'],3)
        self.assertFalse(x['crossing_pairs'])
    def test_crossing(self):
        x=parse_dotbracket('AAAAUUUU','([..)]..')
        self.assertTrue(x['crossing_pairs'])
    def test_malformed(self):
        for dbn in ['((...)))','(((...))','(((..x)))']:
            with self.assertRaises(ValueError):parse_dotbracket('GGGAAACCC',dbn)
    def test_bpseq(self):
        seq='GGGAAACCC'; pairs=[(1,9),(2,8),(3,7)]
        raw='\n'.join(f'{i} {b} {dict(pairs+[(b,a) for a,b in pairs]).get(i,0)}' for i,b in enumerate(seq,1))
        self.assertEqual(parse_bpseq(raw,seq),pairs)
        self.assertEqual(bpseq_to_dotbracket(seq,pairs),'(((...)))')
    def test_nonreciprocal(self):
        with self.assertRaises(ValueError):parse_bpseq('1 G 2\n2 C 0','GC')
    def test_annotate_and_inventory(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);s=root/'samples'/'TEST_A';s.mkdir(parents=True)
            seq='G'*15+'A'*10+'C'*15
            (s/'metadata.json').write_text(json.dumps({'sample_id':'TEST_A','sequence':seq,'missing_c4_count':0,'contiguous':True}))
            f=root/'annotation.dbn';f.write_text('('*15+'.'*10+')'*15)
            r=annotate_sample(s,f,'independent_2d','lab-provided','SHAPE-informed',True)
            self.assertEqual(r['status'],'accepted')
            rows=inventory(root);self.assertEqual(len(rows),2)
            self.assertEqual(rows[0]['status'],'missing_annotation')
            self.assertEqual(rows[1]['status'],'accepted')
    def test_no_provenance(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'metadata.json').write_text(json.dumps({'sample_id':'x','sequence':'G'*40}))
            f=p/'a.dbn';f.write_text('.'*40)
            with self.assertRaises(ValueError):annotate_sample(p,f,'oracle_2d','','tool')

if __name__=='__main__':unittest.main()
