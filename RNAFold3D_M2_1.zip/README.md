# RNAFold3D-Physics — M0/M1 Starter

A minimal, tested, independent RNA secondary-structure parsing and geometry kernel. Intended for RNA up to 200 nt; no machine learning, structure fragments or upstream source code.

## Install and run

```bash
pip install -e .
python -m rnafold3d --sequence GGGAAACCC --structure '(((...)))' --output example.json
python -m unittest discover -s tests -v
```

## Implemented
- Sequence and multi-bracket dot-bracket validation (including crossing base pairs)
- Pair map and consecutive base-pair stem detection
- Unpaired runs and preliminary structural-element adjacency
- Simplified A-form-like helical guide coordinates
- Proper rigid transformations and a conservative endpoint distance feasibility bound
- JSON export and six passing unit tests

## Not implemented
- Complete junction topology graph, precise loop classification, actual atomic A-form RNA geometry, loop closure, physical energies, Monte Carlo, full-atom reconstruction, or validated PDB outputs.

**Important:** Helix points are abstract guide coordinates, not physical atom positions. The endpoint reachability check is only a necessary upper-bound filter, not a sufficient chain-closure test. `T` is normalized to `U`; modified nucleotides are not supported. Bracket types support pseudoknot pair maps but not full pseudoknot topology modeling.

See `M0_AUDIT.md` for source-audit status and follow-up work.

## M1 extension (2026-10-21)

Added `topology.py` and `geometry.py`:
- Planar secondary-structure tree with external, hairpin, bulge, internal-loop, and multibranch-junction nodes, per-arm unpaired segments, and parent-child stem edges.
- Crossing base pairs are **detected but not decomposed**: `supported_planar=false`; `--strict` rejects them. This is intentional, not pseudoknot support.
- Analytic A-form-inspired P/C4'/N three-site **guide coordinates** and stem endpoint frames; proper rigid transformations.
- These sites are synthetic scaffolds, **not experimentally calibrated nucleotide geometries**, and cannot be labeled as validated atom coordinates or exported as all-atom PDBs.
- No loop closure, force field, energy minimization, or physical conformational ensemble yet.

Run: `PYTHONPATH=src python -m rnafold3d --sequence GGGAAACCC --structure '(((...)))' --output demo.json`

Test: `PYTHONPATH=src python -m unittest discover -s tests -v`

The earlier `core.py` `elements` field is retained for backward compatibility; use `topology.junctions` for the authoritative planar topology classification.

## M1.3 + M1.4 extension

`assembly.py` generates multiple seeded, topology-aware rigid-body stem arrangements. It initializes child stems near the parent stem's interior end and applies stochastic rigid translations/rotations, with a simple loop-reachability and inter-stem clash penalty. Scores are **heuristic geometry penalties, not physical free energies**.

`closure.py` implements FABRIK inverse kinematics for virtual C4' guide chains with fixed endpoints and equal virtual link lengths. Every attempted loop returns an explicit `converged` flag, endpoint residual and link-length residual. Unreachable endpoints are reported rather than silently connected. Unpaired terminal tails are not yet modeled; zero-unpaired inter-stem joins are checked. Loop orientation, sugar pucker, atomic torsions, steric clashes, base stacking, and chirality are **not** enforced.

Run a multi-candidate geometry demonstration:

```bash
PYTHONPATH=src python -m rnafold3d --sequence AAAAAAAAAAAAAAAAAAAAAAAA --structure '((..((...))..((...))..))' --assemble 8 --seed 42 --proposals 150 --output m1_assembly.json
PYTHONPATH=src python -m unittest discover -s tests -v
```

These JSON structures are **not PDB predictions**. A reported closure is a mathematical virtual-link closure only, not a chemically valid RNA backbone. Candidates with failed closure must be rejected or repaired in a later constrained optimizer. Pseudoknots are explicitly unsupported by this planar assembly stage.

## M1.5 — Geometry Validation & Candidate Filtering

The new `rnafold3d.validation` module performs **guide-coordinate** checks:
- Attempts C4' virtual-loop closure and records failure reasons and residuals.
- Reports unmodeled residues (including terminal tails); strict filtering rejects incomplete chains.
- Checks nonlocal guide-site clashes between different stems / loop residues, excluding close sequence neighbors and uncalibrated within-stem geometry.
- Checks virtual C4' link continuity outside individual stems.
- Ranks candidates by existing heuristic placement score, then greedily removes near-duplicates using Kabsch-aligned C4' RMSD.
- Returns machine-readable reports, including cluster membership and rejection reasons.

Example:

```bash
python -m rnafold3d --sequence AAAAAAAAAAAAAAAAAAAAAAAA \
  --structure '((..((...))..((...))..))' --assemble 12 --proposals 100 \
  --filter --max-selected 8 --rmsd-threshold 3.0 --seed 42 \
  --output m1_5_results.json
```

`--allow-incomplete` is an **exploratory option only**: terminal tails are still missing from coordinate output. Strict filtering can legitimately return zero candidates; no synthetic success is reported. Thresholds are provisional guide-site diagnostics, not experimentally validated RNA atomic geometry. M1.5 does not output PDB or certify molecular validity. M2 should add physically calibrated potentials and proper backbone geometry.


## M2.1 — Experimental Physics Energy Engine

`rnafold3d.energy` implements an independently testable **guide-coordinate surrogate score** with six components: adjacent C4 guide bonds, secondary-structure base-anchor pairing restraints, pair-facing orientation, direction-sensitive intra-stem stacking, nonlocal C4 steric repulsion, and screened phosphate-guide repulsion. See `EnergyConfig` for tunable parameters and `EnergyBreakdown` for decomposed scores.

**Scientific limitation:** The existing M1 P/C4/N sites are synthetic geometric guides; base-anchor directions are not physical base-plane normals. Energy values are **arbitrary model units, not kcal/mol or free energies**. The pairing term is a secondary-structure restraint, and the stacking term is a simple orientation proxy. Electrostatics omit explicit ions and solvent. This is a tested software foundation, not a validated physical force field. In particular, score comparisons across RNA sequences, lengths, or conformations with different modeled residue counts are not scientifically justified.

Example (stem-only diagnostic scores, not complete RNA conformer energies):

```bash
python -m rnafold3d --sequence AAAAAAAAAAAAAAAAAAAAAAAA \
  --structure '((..((...))..((...))..))' --assemble 4 \
  --score-energy --output m2_1_example.json
```

The optional `m2_1_energy` field is emitted for each assembly and scores **stem sites only**, because the M1 loop solver currently emits C4-only coordinates. The next step is to reconstruct complete P/C4/N loop sites and calibrate/test the geometric representation before physically meaningful conformational optimization.
