# M0: Reference Method Audit (preliminary)

Status: **documentation-level audit complete; source-level audit blocked**. The runtime could not resolve github.com when cloning the repositories. No line-by-line source review has been performed. No upstream code has been copied into this package.

| Method | Verified public reference | Relevant design lesson | Source review status |
|---|---|---|---|
| Ernwin | https://github.com/ViennaRNA/ernwin | Coarse-grained structural-element sampling; optional all-atom reconstruction uses an external structural knowledge base of PDB fragments | Not cloned; LICENSE and internal implementation must be inspected before reuse |
| RNAJP | Literature description; identify authoritative implementation and distribution URL | Junction-specific geometry and interaction modeling | Code availability and exact closure/sampling implementation not verified |
| IsRNA/IsRNA2 | Published method descriptions and server documentation | Coarse-grained nucleotide physics, enhanced sampling, clustering | Source availability, precise bead definitions and redistribution rights require verification |
| TiRNA | https://github.com/Tan-group/TiRNA | P/C4'/N1-or-N9 3-bead model, MCSA/REMC, ion-dependent force field; optional QRNAS refinement | Official README checked; source not cloned; licensing unresolved |

## Immediate M0 follow-up
1. Clone repositories in a network-enabled environment and pin commit hashes.
2. Inspect licenses and dependencies, including force-field parameter files.
3. Identify exact junction moves, chain closure, initial stem orientation and topology transitions from source.
4. Reproduce one small benchmark for each accessible tool.
5. Keep physics and atomistic reconstruction adapters optional, with separate licenses.

## Scope and honesty
This package is an independently written M1 geometry prototype. Its idealized helix guide points are NOT P, C4', C1' or N1/N9 atom coordinates and MUST NOT be written as an atomistic PDB. Loop runs are provisional: full hairpin/internal/bulge/multibranch classification and graph cycle handling are future work.
