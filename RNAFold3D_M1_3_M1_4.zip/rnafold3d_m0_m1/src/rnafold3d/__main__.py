import argparse,json
from dataclasses import asdict
from .core import parse
from .topology import build_topology
from .geometry import aform_three_site,stem_endpoint_frames
from .assembly import assemble
from .closure import close_assembly

def main():
    ap=argparse.ArgumentParser(description='RNAFold3D M1 geometry kernel (not an atomistic RNA predictor)')
    ap.add_argument('--sequence',required=True);ap.add_argument('--structure',required=True)
    ap.add_argument('--output',default='m1_output.json');ap.add_argument('--strict',action='store_true')
    ap.add_argument('--assemble',type=int,default=0,metavar='N',help='Generate N rigid-body topology hypotheses')
    ap.add_argument('--seed',type=int,default=0);ap.add_argument('--proposals',type=int,default=100)
    a=ap.parse_args();m=parse(a.sequence,a.structure);top=build_topology(m,strict=a.strict)
    obj=asdict(m);obj['topology']=asdict(top);obj['stem_geometry']=[]
    for s in m.stems:
        sites=aform_three_site(s)
        obj['stem_geometry'].append({'sites':[asdict(x) for x in sites], 'end_frames':stem_endpoint_frames(sites,s), 'geometry_status':'idealized_unvalidated'})
    if a.assemble:
        candidates=assemble(m,a.assemble,a.seed,a.proposals)
        obj['assemblies']=[]
        for candidate in candidates:
            closures=close_assembly(m,candidate,seed=a.seed+candidate.proposal)
            obj['assemblies'].append({'seed':candidate.seed,'candidate_index':candidate.proposal,
                'placement_score':candidate.placement_score,
                'rotations':candidate.rotations,'translations':candidate.translations,
                'stem_sites':[[asdict(s) for s in sites] for sites in candidate.stem_sites],
                'loop_closures':[asdict(c) for c in closures],
                'all_reported_loops_closed':all(c.converged for c in closures),
                'geometry_status':'unvalidated_guide_coordinates'})
    with open(a.output,'w',encoding='utf-8') as f:json.dump(obj,f,indent=2)
    print(f'{len(m.sequence)} nt; {len(m.stems)} stems; planar={top.supported_planar}; output={a.output}')
if __name__=='__main__':main()
