import unittest, tempfile
from pathlib import Path
from benchmark_dataset import extract_chains
class TestExtraction(unittest.TestCase):
 def test_chain_length_and_sequence(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'x.cif'
   lines=['data_test','loop_','_atom_site.label_asym_id','_atom_site.label_seq_id','_atom_site.label_comp_id','_atom_site.label_atom_id','_atom_site.label_alt_id','_atom_site.pdbx_PDB_model_num']
   for i in range(1,32):lines.append(f"A {i} {('A','C','G','U')[(i-1)%4]} \"C4'\" . 1")
   p.write_text('\n'.join(lines)+'\n')
   cs=extract_chains(p)
   self.assertEqual(len(cs),1);self.assertEqual(cs[0]['length'],31);self.assertEqual(cs[0]['missing_c4_count'],0)
 def test_filter(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'x.cif';p.write_text("data_test\nloop_\n_atom_site.label_asym_id\n_atom_site.label_seq_id\n_atom_site.label_comp_id\n_atom_site.label_atom_id\n_atom_site.label_alt_id\n_atom_site.pdbx_PDB_model_num\nA 1 A P . 1\n")
   self.assertEqual(extract_chains(p),[])
if __name__=='__main__':unittest.main()
