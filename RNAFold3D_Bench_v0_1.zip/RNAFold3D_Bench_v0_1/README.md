# RNAFold3D-Bench v0.1 — real experimental RNA dataset curation

**Status:** reproducible dataset builder with a literature-grounded candidate manifest. **This archive does not contain downloaded experimental structures.** The build environment had no access to `files.rcsb.org`. Do not report any benchmark scores or chain counts before downloading and auditing the structures.

## Sources
- RNA-Puzzles official puzzle table: https://www.rnapuzzles.org/puzzles/list/
- RNA-Puzzles reference/prediction collection: https://github.com/RNA-Puzzles/raw_dataset_and_for_assessment
- RNA 3D Hub representative sets: https://rna.bgsu.edu/rna3dhub/nrlist/
- RCSB download endpoint: https://files.rcsb.org/download/1EHZ.cif

## Install and build
```bash
python -m pip install biopython
python benchmark_dataset.py --manifest candidate_manifest.json --out dataset
```
For reproducibility, download and preserve the original mmCIF files under `dataset/raw/`. Run `--offline` to re-index existing files without network access. `inventory.csv` records failures rather than silently omitting them.

## What the builder does
- Downloads original RCSB mmCIF files without modifying reference coordinates.
- Extracts canonical A/C/G/U RNA chains from model 1, using `_atom_site.label_asym_id` and `label_seq_id`.
- Restricts candidate chains to 30–200 observed canonical nucleotides.
- Records C4' coverage and whether observed positions are contiguous.
- Writes FASTA and per-chain metadata, preserving the original mmCIF reference.
- **Does not invent dot-bracket secondary structures.** All chains remain `needs_2d_and_review` until 2D annotation and scientific review.

## Scientific review required before scoring
1. Verify polymer sequence using `_entity_poly_seq`, accounting for modified residues and missing coordinates. The prototype extractor only counts observed canonical residues; this can underestimate true RNA length.
2. Confirm chain identity, biological assembly, multichain complexes, experimental method, resolution, ligands and metal ions.
3. Obtain **independently sourced** input secondary structures for the strict benchmark. A dot-bracket derived from the reference 3D structure must be labeled `oracle_2d` and evaluated separately.
4. Reject duplicate/homologous RNAs across splits. RNA 3D Hub representative classes help, but are not sufficient to guarantee sequence-family independence.
5. Exclude proteins, DNA, synthetic assemblies or ambiguous chains as appropriate. Document exclusions.
6. Separate 30–49 nt smoke tests, 50–100 nt core, 101–150 nt and 151–200 nt stress cases; stratify by stems, junctions and pseudoknots.
7. Record all failures including missing templates, invalid atom geometry, no candidates, timeouts and software errors.
8. Evaluate Top-1 and Best-of-K C4' RMSD, coverage, ensemble diversity, eRMSD/INF using independently validated implementations, stereochemistry, runtime and success rate. Report K and compute budget.

## Dataset policy
- Do not use reference tertiary coordinates, inferred contacts, or structure-derived loop fragments during prediction.
- Store source, retrieval date, mmCIF hash, chain mapping, 2D provenance, software versions, random seeds and environmental conditions.
- `status=needs_2d_and_review` is not a validated benchmark item.
- Original experimental structures remain separate from generated models.
- Reference structural data are obtained from original sources and must follow their terms and attribution requirements.

## Suggested layout
```
dataset/
  raw/3V7E.cif
  samples/3V7E_<chain>/sequence.fasta
  samples/3V7E_<chain>/metadata.json
  inventory.csv
```

## Important limitations
- RNA chains in complex assemblies can have discontinuous numbering or noncanonical residues; the script reports but does not repair them.
- No 2D annotations or PDB-derived scores are provided by default.
- This is a curation starting point, not a finished scientifically audited benchmark.
