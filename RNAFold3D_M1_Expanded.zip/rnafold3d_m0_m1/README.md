# RNAFold3D-Physics — M0/M1 Starter

A minimal, tested, independent RNA secondary-structure parsing and geometry kernel. Intended for RNA up to 200 nt; no machine learning, structure fragments or upstream source code.

## Install and run

```bash
pip install -e .
python -m rnafold3d --sequence GGGAAACCC --structure '(((...)))' --output example.json
python -m unittest discover -s tests -v
```

## Implemented
- Sequence and multi-bracket dot-bracket validation (including crossing base pairs)
- Pair map and consecutive base-pair stem detection
- Unpaired runs and preliminary structural-element adjacency
- Simplified A-form-like helical guide coordinates
- Proper rigid transformations and a conservative endpoint distance feasibility bound
- JSON export and six passing unit tests

## Not implemented
- Complete junction topology graph, precise loop classification, actual atomic A-form RNA geometry, loop closure, physical energies, Monte Carlo, full-atom reconstruction, or validated PDB outputs.

**Important:** Helix points are abstract guide coordinates, not physical atom positions. The endpoint reachability check is only a necessary upper-bound filter, not a sufficient chain-closure test. `T` is normalized to `U`; modified nucleotides are not supported. Bracket types support pseudoknot pair maps but not full pseudoknot topology modeling.

See `M0_AUDIT.md` for source-audit status and follow-up work.

## M1 extension (2026-10-21)

Added `topology.py` and `geometry.py`:
- Planar secondary-structure tree with external, hairpin, bulge, internal-loop, and multibranch-junction nodes, per-arm unpaired segments, and parent-child stem edges.
- Crossing base pairs are **detected but not decomposed**: `supported_planar=false`; `--strict` rejects them. This is intentional, not pseudoknot support.
- Analytic A-form-inspired P/C4'/N three-site **guide coordinates** and stem endpoint frames; proper rigid transformations.
- These sites are synthetic scaffolds, **not experimentally calibrated nucleotide geometries**, and cannot be labeled as validated atom coordinates or exported as all-atom PDBs.
- No loop closure, force field, energy minimization, or physical conformational ensemble yet.

Run: `PYTHONPATH=src python -m rnafold3d --sequence GGGAAACCC --structure '(((...)))' --output demo.json`

Test: `PYTHONPATH=src python -m unittest discover -s tests -v`

The earlier `core.py` `elements` field is retained for backward compatibility; use `topology.junctions` for the authoritative planar topology classification.
