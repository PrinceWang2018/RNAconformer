import argparse,json
from dataclasses import asdict
from .core import parse
from .topology import build_topology
from .geometry import aform_three_site,stem_endpoint_frames

def main():
    ap=argparse.ArgumentParser(description='RNAFold3D M1 topology and three-site geometry kernel')
    ap.add_argument('--sequence',required=True);ap.add_argument('--structure',required=True)
    ap.add_argument('--output',default='m1_output.json');ap.add_argument('--strict',action='store_true')
    a=ap.parse_args();m=parse(a.sequence,a.structure);top=build_topology(m,strict=a.strict)
    obj=asdict(m);obj['topology']=asdict(top);obj['stem_geometry']=[]
    for s in m.stems:
        sites=aform_three_site(s)
        obj['stem_geometry'].append({'sites': [asdict(x) for x in sites], 'end_frames':stem_endpoint_frames(sites,s), 'geometry_status':'idealized_unvalidated'})
    with open(a.output,'w') as f:json.dump(obj,f,indent=2)
    print(f'{len(m.sequence)} nt; {len(m.stems)} stems; planar={top.supported_planar}; output={a.output}')
if __name__=='__main__':main()
