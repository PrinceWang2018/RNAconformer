# M3 — Experimental Atomistic Reconstruction and PDB Export

This milestone introduces a **fail-closed, template-fitted atomistic export adapter**, not a chemically validated RNA reconstruction algorithm.

## Scope

- **M3.1 (experimental):** fit chemically complete, user-provided canonical RNA residue PDB templates to P/C4'/N1-or-N9 guide coordinates using a proper rigid Kabsch rotation.
- **M3.2 (diagnostic only):** inspect inter-residue O3'–P linkage distances, nonlocal heavy-atom clashes, and per-residue anchor fitting residuals. **No molecular mechanics refinement is implemented.**
- **M3.3 (partial):** emit PDB files only when basic checks pass, plus a JSON manifest and explicit rejection reasons. mmCIF and complete stereochemical validation are pending.

## Why external templates?

The M2 guide sites are synthetic and do not determine ribose pucker, phosphate torsions, or chemically correct atom positions. Independent rigid fitting of full-residue templates preserves each residue's internal geometry, but **cannot guarantee covalent continuity across residues**. This module therefore rejects most arbitrary M2 outputs instead of silently creating invalid full-atom structures. It is a scaffold for a future chain-aware reconstruction/refinement backend (e.g., an independently licensed RNA reconstruction tool and validated force field).

## Usage

Supply one chemically complete, correctly named single-residue PDB template for each base present in the sequence. The templates must contain P, C4', N9 (A/G) or N1 (C/U), O3', O5', C3', C5', C1' and enough additional heavy atoms. Input is an M2 JSON result.

```bash
python -m rnafold3d.m3_cli --input ensemble.json \
  --template-a templates/A.pdb --template-c templates/C.pdb \
  --template-g templates/G.pdb --template-u templates/U.pdb \
  --outdir atomistic_out
```

`--allow-invalid-debug` is only for inspecting rejected geometries; such files are labeled invalid in `manifest.json` and **must not** be treated as valid structures.

## Remaining before claiming M3 completion

1. Validated residue templates with proper atom names and stereochemistry.
2. Chain-aware inverse kinematics or restrained atomistic minimization that closes all O3'–P bonds without destroying base-pair geometry.
3. Complete bond/angle/torsion, sugar-pucker, chirality and clash validation.
4. mmCIF writer and standards-compliant ensemble provenance.
5. Benchmarking against experimental RNA structures and independent validators.
